package kr.sparta.practical2_starter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Practical2StarterApplicationTests {

    @Test
    void contextLoads() {
    }

}
