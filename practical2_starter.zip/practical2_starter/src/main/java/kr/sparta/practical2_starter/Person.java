package kr.sparta.practical2_starter;

/*
 model
 */
public class Person {
}
