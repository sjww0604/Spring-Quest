package kr.sparta.practical2_starter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Practical2StarterApplication {

    public static void main(String[] args) {
        SpringApplication.run(Practical2StarterApplication.class, args);
    }

}
