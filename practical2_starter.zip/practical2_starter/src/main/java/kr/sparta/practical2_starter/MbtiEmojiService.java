package kr.sparta.practical2_starter;

import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class MbtiEmojiService {

}
